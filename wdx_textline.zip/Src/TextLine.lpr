library TextLine;

{$mode delphi}{$H+}

// Text Line - Content (WDX) plugin for Total Commander.
// Original by Alexey Fomin. Ported to Lazarus/FPC (32/64 bit) and extended:
//   * fields for the 3rd-last, 2nd-last and last line
//   * a numeric "Line count" field
//   * proper Unicode handling: UTF-8 and UTF-16 (LE/BE), with or without BOM,
//     plus legacy single-byte ANSI/OEM via the win|dos unit.
//
// Build:
//   - Open TextLine.lpi in Lazarus, pick build mode "Win32" -> TextLine.wdx
//     or "Win64" -> TextLine.wdx64, then Run > Build.

uses
  Windows,
  SysUtils,
  ContPlug,
  SProc;

const
  MAX_FIRST   = 10;        // fields 0..9   -> line 1..10
  TAIL_FIELDS = 3;         // fields 10..12 -> 3rd-last, 2nd-last, last line
  IDX_COUNT   = MAX_FIRST + TAIL_FIELDS;       // field 13 -> line count
  IDX_ENCODING = IDX_COUNT + 1;                 // field 14 -> encoding
  IDX_TYPE     = IDX_ENCODING + 1;               // field 15 -> text/binary/folder
  IDX_EOL      = IDX_TYPE + 1;                   // field 16 -> line-ending style
  MAX_FIELD   = IDX_EOL;                         // = 16

  CHUNK_SIZE  = 1 shl 16;      // 64 KB head/tail chunk
  TAIL_MAX    = 4 shl 20;      // cap when escalating head/tail reads
  COUNT_BLOCK = 4 shl 20;      // 4 MB streaming block for the line counter

  cpACP   = 0;       // system ANSI code page
  cpOEMCP = 1;       // system OEM (DOS) code page
  cpUTF8  = 65001;

type
  TEnc = (encAnsi, encUtf8, encUtf16LE, encUtf16BE);
  TFileKind = (fkText, fkBinary);
  TByteFlags = array[0..255] of Boolean;

var
  // --- settings (loaded once in Init) ---
  fnIni: WideString;
  fExt: WideString;
  fSkip: boolean;
  fTextBufferKB: Integer;
  fUtf8BufferKB: Integer;
  fOemEnabled: Boolean;
  fOemBufferKB: Integer;
  fOemPercent: Integer;
  fRusEnabled: Boolean;
  fRusBufferKB: Integer;
  fRusMinSize: Integer;
  fRusPercent: Integer;
  fRusWordLen: Integer;
  fBinaryIgnore: TByteFlags;
  fOemIgnore: TByteFlags;
  fReplaces: array[1..20] of
    record sFrom, sTo: WideString; end;

  // --- per-file cache (one entry, guarded by CacheCS) ---
  // File metadata is established once per file version (name/size/mtime);
  // the three result groups below are each filled lazily and independently,
  // so asking only for line 1 never touches the tail or counts the lines.
  CacheCS: TRTLCriticalSection;
  CacheValid: Boolean = False;    // metadata established & file readable
  CacheName: WideString;
  CacheSize: Int64;
  CacheTime: Int64;
  CacheFileEnc: TEnc;             // detected encoding of the file
  CacheBomLen: Integer;           // length of a leading BOM, if any
  CacheLineIsUtf8: Boolean;       // True -> stored line bytes are UTF-8, else raw ANSI/OEM
  CacheHead: AnsiString;          // at most CHUNK_SIZE, shared by all detectors
  CacheKindValid: Boolean;
  CacheKind: TFileKind;
  CacheEncodingValid: Boolean;
  CacheEncoding: AnsiString;
  CacheEolValid: Boolean;
  CacheEol: AnsiString;
  // line text is stored as byte strings: UTF-8 for Unicode files, raw bytes for ANSI
  CacheFirstValid: Boolean;
  CacheFirst: array[0..MAX_FIRST-1] of AnsiString;
  CacheFirstCount: Integer;
  CacheLastValid: Boolean;
  CacheLast: array[0..TAIL_FIELDS-1] of AnsiString; // oldest..newest of the last lines
  CacheLastCount: Integer;
  CacheLineCountValid: Boolean;
  CacheLineCount: Int64;

//==============================================================
// Field descriptions
//==============================================================
function ContentGetSupportedField(FieldIndex: integer;
  FieldName, Units: pAnsiChar;
  maxlen: integer): integer; stdcall;
const
  cTailNames: array[0..TAIL_FIELDS-1] of AnsiString =
    ('-3', '-2', '-1');
var
  nm: AnsiString;
begin
  if (FieldIndex < 0) or (FieldIndex > MAX_FIELD) then
    begin Result := FT_NOMOREFIELDS; Exit end;

  if FieldIndex = IDX_COUNT then
  begin
    lstrcpynA(FieldName, 'Line count', MaxLen);
    lstrcpynA(Units, '', MaxLen);
    Result := FT_NUMERIC_64;
    Exit;
  end;

  if FieldIndex = IDX_ENCODING then
  begin
    lstrcpynA(FieldName, 'Encoding', MaxLen);
    lstrcpynA(Units,
      'UTF-16 LE|UTF-16 BE|UTF-8 BOM|UTF-8 no BOM|ANSI|ANSI Ru|DOS|DOS Ru|RTF|Binary',
      MaxLen);
    Result := FT_MULTIPLECHOICE;
    Exit;
  end;

  if FieldIndex = IDX_TYPE then
  begin
    lstrcpynA(FieldName, 'Type', MaxLen);
    lstrcpynA(Units, 'Folder|Binary|Text', MaxLen);
    Result := FT_MULTIPLECHOICE;
    Exit;
  end;

  if FieldIndex = IDX_EOL then
  begin
    lstrcpynA(FieldName, 'Line ending', MaxLen);
    lstrcpynA(Units, 'Windows|Unix|Mac|Mixed|None', MaxLen);
    Result := FT_MULTIPLECHOICE;
    Exit;
  end;

  if FieldIndex < MAX_FIRST then
    nm := IntToStr(FieldIndex + 1)               // "1".."10"
  else
    nm := cTailNames[FieldIndex - MAX_FIRST];

  lstrcpynA(FieldName, PAnsiChar(nm), MaxLen);
  lstrcpynA(Units, 'win|dos', MaxLen);
  Result := FT_STRINGW;
end;

//==============================================================
// Settings
//==============================================================
function GetModuleFile: WideString;
var
  buf: array[0..MAX_PATH] of WideChar;
begin
  if GetModuleFileNameW(HINST(HInstance), @buf[0], MAX_PATH) > 0 then
    Result := WideString(PWideChar(@buf[0]))
  else
    Result := '';
end;

function GetCfgInt(const key: WideString; default, minValue,
  maxValue: Integer): Integer;
begin
  Result := StrToIntDef(AnsiString(GetIniKeyW('Encoding', key,
    WideString(IntToStr(default)), fnIni)), default);
  if Result < minValue then Result := minValue;
  if Result > maxValue then Result := maxValue;
end;

procedure ParseIgnoreBytes(const value: WideString; var flags: TByteFlags);
var
  i: Integer;
  padded: WideString;
begin
  FillChar(flags, SizeOf(flags), 0);
  padded := ' ' + UpperCase(Trim(value)) + ' ';
  for i := Low(flags) to High(flags) do
    if Pos(' ' + WideString(IntToHex(i, 2)) + ' ', padded) > 0 then
      flags[i] := True;
end;

procedure Init;
var
  n: Integer;
  p: Integer;
  s, fnMod: WideString;
begin
  fnMod := GetModuleFile;
  p := Length(fnMod);
  while (p > 0) and (fnMod[p] <> '.') and
    (fnMod[p] <> '\\') and (fnMod[p] <> '/') do Dec(p);
  if (p > 0) and (fnMod[p] = '.') then
    fnIni := Copy(fnMod, 1, p - 1) + '.ini'
  else
    fnIni := fnMod + '.ini';

  fExt  := LowerCase(Trim(GetIniKeyW('Options', 'Extensions', '', fnIni)));
  fSkip := (GetIniKeyW('Options', 'SkipEmpty', '0', fnIni) <> '0');

  // EncInfo-compatible defaults. All buffers are capped at the already cached
  // 64 KiB header, so classification never causes another file read.
  fTextBufferKB := GetCfgInt('TextBufferSizeKB', 1, 1, CHUNK_SIZE div 1024);
  fUtf8BufferKB := GetCfgInt('Utf8BufferSizeKB', 64, 1, CHUNK_SIZE div 1024);
  fOemEnabled := GetCfgInt('OemEnabled', 1, 0, 1) <> 0;
  fOemBufferKB := GetCfgInt('OemBufferSizeKB', 1, 1, CHUNK_SIZE div 1024);
  fOemPercent := GetCfgInt('OemPercent', 18, 0, 100);
  fRusEnabled := GetCfgInt('RusEnabled', 1, 0, 1) <> 0;
  fRusBufferKB := GetCfgInt('RusBufferSizeKB', 2, 1, CHUNK_SIZE div 1024);
  fRusMinSize := GetCfgInt('RusMinSize', 8, 0, CHUNK_SIZE);
  fRusPercent := GetCfgInt('RusPercent', 30, 0, 100);
  fRusWordLen := GetCfgInt('RusWordLen', 0, 0, CHUNK_SIZE);
  ParseIgnoreBytes(GetIniKeyW('Encoding', 'BinaryIgnore', '', fnIni),
    fBinaryIgnore);
  ParseIgnoreBytes(GetIniKeyW('Encoding', 'OemIgnore', 'AB BB', fnIni),
    fOemIgnore);

  for n := Low(fReplaces) to High(fReplaces) do
  begin
    s := GetIniKeyW('Replaces', WideString('S' + IntToStr(n)), '=', fnIni);
    p := Pos('=', s);
    if p > 0 then
    begin
      fReplaces[n].sFrom := Copy(s, 1, p - 1);
      fReplaces[n].sTo   := Copy(s, p + 1, MaxInt);
    end
    else
    begin
      fReplaces[n].sFrom := '';
      fReplaces[n].sTo := '';
    end;
  end;
end;

procedure ReplaceAllW(var s: WideString; const sFrom, sTo: WideString);
var
  p, start: Integer;
begin
  if sFrom = '' then Exit;
  start := 1;
  repeat
    p := Pos(sFrom, Copy(s, start, MaxInt));
    if p = 0 then Exit;
    Inc(p, start - 1);
    Delete(s, p, Length(sFrom));
    Insert(sTo, s, p);
    start := p + Length(sTo);
  until False;
end;

//==============================================================
// Encoding helpers
//==============================================================
function AnsiToWide(const s: AnsiString; cp: UINT): WideString;
var n: Integer;
begin
  Result := '';
  if s = '' then Exit;
  n := MultiByteToWideChar(cp, 0, PAnsiChar(s), Length(s), nil, 0);
  if n <= 0 then Exit;
  SetLength(Result, n);
  MultiByteToWideChar(cp, 0, PAnsiChar(s), Length(s), PWideChar(Result), n);
end;

function WideToUtf8(const ws: UnicodeString): AnsiString;
var n: Integer;
begin
  Result := '';
  if ws = '' then Exit;
  n := WideCharToMultiByte(cpUTF8, 0, PWideChar(ws), Length(ws), nil, 0, nil, nil);
  if n <= 0 then Exit;
  SetLength(Result, n);
  WideCharToMultiByte(cpUTF8, 0, PWideChar(ws), Length(ws), PAnsiChar(Result), n, nil, nil);
end;

// Convert raw UTF-16 bytes (optionally byte-swapped for BE) to UTF-8 bytes.
function Utf16ToUtf8(const buf: AnsiString; be: Boolean; bomLen: Integer): AnsiString;
var
  ws: UnicodeString;
  n, i: Integer;
begin
  n := (Length(buf) - bomLen) div 2;
  if n <= 0 then begin Result := ''; Exit end;
  SetLength(ws, n);
  Move(buf[bomLen + 1], ws[1], n * 2);
  if be then
    for i := 1 to n do
      ws[i] := WideChar(Swap(Word(ws[i])));
  Result := WideToUtf8(ws);
end;

function LooksUtf8(const buf: AnsiString): Boolean;
var
  i, L, cont: Integer;
  b: Byte;
  hasMulti: Boolean;
begin
  L := Length(buf);
  i := 1;
  hasMulti := False;
  while i <= L do
  begin
    b := Byte(buf[i]);
    if b < $80 then
      cont := 0
    else if (b and $E0) = $C0 then begin cont := 1; hasMulti := True end
    else if (b and $F0) = $E0 then begin cont := 2; hasMulti := True end
    else if (b and $F8) = $F0 then begin cont := 3; hasMulti := True end
    else begin Result := False; Exit end;     // invalid lead byte
    Inc(i);
    while cont > 0 do
    begin
      if i > L then begin Result := hasMulti; Exit end;  // truncated at chunk edge
      if (Byte(buf[i]) and $C0) <> $80 then begin Result := False; Exit end;
      Inc(i); Dec(cont);
    end;
  end;
  Result := hasMulti;
end;

function LooksUtf16(const buf: AnsiString; out be: Boolean): Boolean;
var
  k, L, lim, pairs, zEven, zOdd: Integer;
begin
  be := False;
  L := Length(buf);
  lim := L; if lim > 4096 then lim := 4096;
  if (lim and 1) <> 0 then Dec(lim);
  pairs := lim div 2;
  if pairs = 0 then Exit(False);
  // The overwhelmingly common ANSI/UTF-8 case contains no NUL at all.
  // IndexByte uses the optimized RTL search and avoids the Pascal pair loop.
  if IndexByte(buf[1], lim, 0) < 0 then Exit(False);
  zEven := 0; zOdd := 0;
  for k := 0 to pairs - 1 do
  begin
    if buf[2*k + 1] = #0 then Inc(zEven);
    if buf[2*k + 2] = #0 then Inc(zOdd);
  end;

  // A one-character ASCII UTF-16 file has only one zero byte. For longer
  // buffers require repeated zeros on one consistent byte lane; this avoids
  // treating short binary headers containing an incidental NUL as UTF-16.
  if pairs = 1 then
  begin
    Result := (zEven = 1) xor (zOdd = 1);
    if Result then be := zEven = 1;
  end
  else
  begin
    if (zOdd >= 2) and (zOdd * 4 >= pairs) and (zEven * 4 < zOdd) then
    begin
      be := False;
      Result := True;
    end
    else if (zEven >= 2) and (zEven * 4 >= pairs) and (zOdd * 4 < zEven) then
    begin
      be := True;
      Result := True;
    end
    else
      Result := False;
  end;
end;

function DetectEnc(const buf: AnsiString; out bomLen: Integer): TEnc;
var
  L: Integer;
  be: Boolean;
  utf8Sample: AnsiString;
begin
  bomLen := 0;
  L := Length(buf);
  if (L >= 3) and (Byte(buf[1]) = $EF) and (Byte(buf[2]) = $BB) and (Byte(buf[3]) = $BF) then
    begin bomLen := 3; Result := encUtf8; Exit end;
  if (L >= 2) and (Byte(buf[1]) = $FF) and (Byte(buf[2]) = $FE) then
    begin bomLen := 2; Result := encUtf16LE; Exit end;
  if (L >= 2) and (Byte(buf[1]) = $FE) and (Byte(buf[2]) = $FF) then
    begin bomLen := 2; Result := encUtf16BE; Exit end;
  if LooksUtf16(buf, be) then
  begin
    if be then Result := encUtf16BE else Result := encUtf16LE;
    Exit;
  end;
  if Length(buf) <= fUtf8BufferKB * 1024 then
  begin
    if LooksUtf8(buf) then begin Result := encUtf8; Exit end;
  end
  else
  begin
    utf8Sample := Copy(buf, 1, fUtf8BufferKB * 1024);
    if LooksUtf8(utf8Sample) then begin Result := encUtf8; Exit end;
  end;
  Result := encAnsi;
end;

function StartsWithRtf(const buf: AnsiString): Boolean;
begin
  Result := (Length(buf) >= 5) and
    (buf[1] = '{') and (buf[2] = '\') and (buf[3] = 'r') and
    (buf[4] = 't') and (buf[5] = 'f');
end;

function IsBinaryHeader(const buf: AnsiString): Boolean;
var
  i, limit, b: Integer;
begin
  Result := False;
  limit := Length(buf);
  if limit > fTextBufferKB * 1024 then limit := fTextBufferKB * 1024;
  for i := 1 to limit do
  begin
    b := Byte(buf[i]);
    if (b < 32) and (b <> 9) and (b <> 10) and (b <> 13) and
      (not fBinaryIgnore[b]) then
      Exit(True);
  end;
end;

function IsOemHeader(const buf: AnsiString): Boolean;
var
  table: array[$80..$FF] of Integer;
  i, limit, highCount, b: Integer;
begin
  Result := False;
  FillChar(table, SizeOf(table), 0);
  limit := Length(buf);
  if limit > fOemBufferKB * 1024 then limit := fOemBufferKB * 1024;
  highCount := 0;
  for i := 1 to limit do
  begin
    b := Byte(buf[i]);
    if b >= $80 then
    begin
      Inc(highCount);
      Inc(table[b]);
    end;
  end;
  if highCount = 0 then Exit;
  for b := Low(table) to High(table) do
    if (not fOemIgnore[b]) and
      (((b >= $B0) and (b <= $DF)) or (b = $FF)) and
      ((table[b] * 100 div highCount) >= fOemPercent) then
      Exit(True);
end;

function IsRusByte(b: Byte; oemMode: Boolean): Boolean; inline;
begin
  if oemMode then
    Result := ((b >= $80) and (b <= $AF)) or
      ((b >= $E0) and (b <= $F1))
  else
    Result := b >= $C0;
end;

function IsRusHeader(const buf: AnsiString; oemMode: Boolean): Boolean;
var
  i, limit, count, wordLen: Integer;
begin
  Result := False;
  limit := Length(buf);
  if limit > fRusBufferKB * 1024 then limit := fRusBufferKB * 1024;
  if limit < fRusMinSize then Exit;
  count := 0;
  wordLen := 0;
  for i := 1 to limit do
    if IsRusByte(Byte(buf[i]), oemMode) then
    begin
      Inc(count);
      Inc(wordLen);
      if (fRusWordLen > 0) and (wordLen >= fRusWordLen) then Exit(True);
    end
    else
      wordLen := 0;
  Result := (limit > 0) and ((count * 100 div limit) >= fRusPercent);
end;

procedure EnsureKind;
begin
  if CacheKindValid then Exit;
  if (CacheSize = 0) or (CacheFileEnc <> encAnsi) or
    (not IsBinaryHeader(CacheHead)) then
    CacheKind := fkText
  else
    CacheKind := fkBinary;
  CacheKindValid := True;
end;

procedure EnsureEncoding;
begin
  if CacheEncodingValid then Exit;
  case CacheFileEnc of
    encUtf16LE: CacheEncoding := 'UTF-16 LE';
    encUtf16BE: CacheEncoding := 'UTF-16 BE';
    encUtf8:
      if CacheBomLen > 0 then CacheEncoding := 'UTF-8 BOM'
      else CacheEncoding := 'UTF-8 no BOM';
  else
    if StartsWithRtf(CacheHead) then
      CacheEncoding := 'RTF'
    else
    begin
      EnsureKind;
      if CacheKind = fkBinary then
        CacheEncoding := 'Binary'
      else if fOemEnabled and IsOemHeader(CacheHead) then
        CacheEncoding := 'DOS'
      else if fRusEnabled and IsRusHeader(CacheHead, False) then
        CacheEncoding := 'ANSI Ru'
      else if fRusEnabled and IsRusHeader(CacheHead, True) then
        CacheEncoding := 'DOS Ru'
      else
        CacheEncoding := 'ANSI';
    end;
  end;
  CacheEncodingValid := True;
end;

procedure CountEolCode(code: Word; var pendingCR: Boolean;
  var windowsCount, unixCount, macCount: Integer); inline;
begin
  if pendingCR then
  begin
    if code = 10 then
    begin
      Inc(windowsCount);
      pendingCR := False;
      Exit;
    end;
    Inc(macCount);
    pendingCR := False;
  end;
  if code = 13 then
    pendingCR := True
  else if code = 10 then
    Inc(unixCount);
end;

procedure EnsureEol;
var
  i, L, kinds, windowsCount, unixCount, macCount: Integer;
  code: Word;
  pendingCR, complete: Boolean;
begin
  if CacheEolValid then Exit;
  CacheEol := '';
  EnsureKind;
  if CacheKind = fkBinary then
  begin
    CacheEolValid := True;
    Exit;
  end;

  L := Length(CacheHead);
  windowsCount := 0;
  unixCount := 0;
  macCount := 0;
  pendingCR := False;
  complete := Int64(L) >= CacheSize;

  if CacheFileEnc in [encUtf16LE, encUtf16BE] then
  begin
    i := CacheBomLen + 1;
    while i + 1 <= L do
    begin
      if CacheFileEnc = encUtf16BE then
        code := (Word(Byte(CacheHead[i])) shl 8) or Byte(CacheHead[i + 1])
      else
        code := Byte(CacheHead[i]) or (Word(Byte(CacheHead[i + 1])) shl 8);
      CountEolCode(code, pendingCR, windowsCount, unixCount, macCount);
      Inc(i, 2);
    end;
  end
  else
  begin
    i := CacheBomLen + 1;
    while i <= L do
    begin
      CountEolCode(Byte(CacheHead[i]), pendingCR,
        windowsCount, unixCount, macCount);
      Inc(i);
    end;
  end;

  // A CR at a partial-buffer boundary may be followed by LF outside the
  // cached header. Count it as classic Mac only when the buffer reaches EOF.
  if pendingCR and complete then Inc(macCount);

  kinds := 0;
  if windowsCount > 0 then Inc(kinds);
  if unixCount > 0 then Inc(kinds);
  if macCount > 0 then Inc(kinds);
  if kinds > 1 then CacheEol := 'Mixed'
  else if windowsCount > 0 then CacheEol := 'Windows'
  else if unixCount > 0 then CacheEol := 'Unix'
  else if macCount > 0 then CacheEol := 'Mac'
  else CacheEol := 'None';
  CacheEolValid := True;
end;

// Turn a raw byte chunk into the stored line representation:
// UTF-8 bytes for any Unicode file, raw bytes for ANSI. bomLen is only
// non-zero for the head/whole chunk (the tail never carries a BOM).
function ProcessChunk(const raw: AnsiString; enc: TEnc; bomLen: Integer): AnsiString;
begin
  case enc of
    encUtf16LE: Result := Utf16ToUtf8(raw, False, bomLen);
    encUtf16BE: Result := Utf16ToUtf8(raw, True, bomLen);
    encUtf8:    Result := Copy(raw, bomLen + 1, MaxInt);
  else
    Result := Copy(raw, bomLen + 1, MaxInt);   // ANSI (bomLen = 0)
  end;
end;

//==============================================================
// Line extraction (byte level on processed UTF-8/ANSI buffers;
// newline 0x0A never occurs inside a UTF-8 multibyte sequence)
//==============================================================
procedure StripCR(var s: AnsiString); inline;
begin
  if (s <> '') and (s[Length(s)] = #13) then
    SetLength(s, Length(s) - 1);
end;

// A line is "empty" (for SkipEmpty) when it holds only blank bytes, i.e. the
// same characters Trim removes (<= #32). Works on UTF-8 too: any non-ASCII
// byte is >= $80 and therefore counts as content.
function IsBlank(const s: AnsiString): Boolean;
var i: Integer;
begin
  for i := 1 to Length(s) do
    if Byte(s[i]) > $20 then begin Result := False; Exit end;
  Result := True;
end;

// Invalidate all lazily-built result groups (called when the file changed).
procedure ResetResults;
var i: Integer;
begin
  CacheKindValid := False;
  CacheEncodingValid := False;
  CacheEolValid := False;
  CacheFirstValid := False;
  CacheFirstCount := 0;
  CacheLastValid := False;
  CacheLastCount := 0;
  CacheLineCountValid := False;
  CacheLineCount := 0;
  for i := 0 to MAX_FIRST-1 do CacheFirst[i] := '';
  for i := 0 to TAIL_FIELDS-1 do CacheLast[i] := '';
end;

procedure ParseFirst(const buf: AnsiString; complete: Boolean);
var
  i, L, start, cnt: Integer;
  line: AnsiString;
begin
  L := Length(buf);
  cnt := 0;
  start := 1;
  i := 1;
  while (i <= L) and (cnt < MAX_FIRST) do
  begin
    if buf[i] = #10 then
    begin
      line := Copy(buf, start, i - start);
      StripCR(line);
      if not (fSkip and IsBlank(line)) then
      begin
        CacheFirst[cnt] := line;
        Inc(cnt);
      end;
      start := i + 1;
    end;
    Inc(i);
  end;
  if complete and (cnt < MAX_FIRST) and (start <= L) then
  begin
    line := Copy(buf, start, L - start + 1);
    StripCR(line);
    if not (fSkip and IsBlank(line)) then
    begin
      CacheFirst[cnt] := line;
      Inc(cnt);
    end;
  end;
  CacheFirstCount := cnt;
end;

// Collect the last up to TAIL_FIELDS lines by scanning backwards from the end,
// so only the few needed lines are materialised (no full-buffer split).
// startsAtBOF tells whether buf begins at the start of the file; if not, the
// leading (cut) segment is a partial line and must be ignored.
procedure ParseLast(const buf: AnsiString; startsAtBOF: Boolean);
var
  i, L, lineEnd, collected: Integer;
  line: AnsiString;
  temp: array[0..TAIL_FIELDS-1] of AnsiString;   // newest-first
begin
  CacheLastCount := 0;
  for i := 0 to TAIL_FIELDS - 1 do temp[i] := '';
  L := Length(buf);
  if L = 0 then Exit;

  i := L;
  if buf[i] = #10 then Dec(i);     // a final newline's empty segment is not a line
  lineEnd := i;                    // inclusive end of the line currently being assembled
  collected := 0;

  while (i >= 1) and (collected < TAIL_FIELDS) do
  begin
    if buf[i] = #10 then
    begin
      line := Copy(buf, i + 1, lineEnd - i);
      StripCR(line);
      if (not fSkip) or (not IsBlank(line)) then
      begin
        temp[collected] := line;
        Inc(collected);
      end;
      lineEnd := i - 1;
    end;
    Dec(i);
  end;

  // the leading segment (buf[1..lineEnd]) is a real line only at the file start
  if (collected < TAIL_FIELDS) and startsAtBOF and (lineEnd >= 1) then
  begin
    line := Copy(buf, 1, lineEnd);
    StripCR(line);
    if (not fSkip) or (not IsBlank(line)) then
    begin
      temp[collected] := line;
      Inc(collected);
    end;
  end;

  // store oldest..newest: CacheLast[collected-1] is the very last line (temp[0])
  CacheLastCount := collected;
  for i := 0 to collected - 1 do
    CacheLast[collected - 1 - i] := temp[i];
end;

//==============================================================
// File reading
//==============================================================
function OpenRead(const fn: WideString): THandle;
begin
  Result := CreateFileW(PWideChar(fn), GENERIC_READ,
    FILE_SHARE_READ or FILE_SHARE_WRITE or FILE_SHARE_DELETE,
    nil, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, 0);
end;

function ReadChunk(h: THandle; ofs: Int64; count: Integer): AnsiString;
var got: Integer;
begin
  Result := '';
  if count <= 0 then Exit;
  SetLength(Result, count);
  FileSeek(h, ofs, 0);
  got := FileRead(h, Result[1], count);
  if got < 0 then got := 0;
  if got < count then SetLength(Result, got);
end;

function ClampLen(sz: Int64; max: Integer): Integer;
begin
  if sz < max then Result := Integer(sz) else Result := max;
end;

// Whole-file line counter: one sequential pass over the open handle, encoding
// aware. With skip, blank lines are not counted; a trailing newline does not
// add a phantom empty line.
function CountLinesStream(h: THandle; enc: TEnc; bomLen: Integer;
  skip: Boolean): Int64;
var
  raw: AnsiString;
  got, n, i, first: Integer;
  nl, total: Int64;
  hasContent, hasAny, be, firstBlock: Boolean;
  lo, hi, t: Byte;
  w: Word;
begin
  Result := 0;
  FileSeek(h, Int64(0), 0);
  nl := 0; total := 0; hasContent := False; hasAny := False;
  be := (enc = encUtf16BE);
  firstBlock := True;
  SetLength(raw, COUNT_BLOCK);
  repeat
    got := FileRead(h, raw[1], COUNT_BLOCK);
    if got <= 0 then Break;
    Inc(total, got);
    if enc in [encUtf16LE, encUtf16BE] then
    begin
      n := got div 2;
      if firstBlock then first := bomLen div 2 else first := 0;
      for i := first to n - 1 do
      begin
        lo := Byte(raw[2*i + 1]); hi := Byte(raw[2*i + 2]);
        if be then begin t := lo; lo := hi; hi := t end;
        w := lo or (hi shl 8);
        if w = 10 then
        begin
          if (not skip) or hasContent then Inc(nl);
          hasContent := False; hasAny := False;
        end
        else
        begin
          hasAny := True;
          if w > $20 then hasContent := True;
        end;
      end;
    end
    else
    begin
      if firstBlock then first := bomLen + 1 else first := 1;
      for i := first to got do
      begin
        lo := Byte(raw[i]);
        if lo = 10 then
        begin
          if (not skip) or hasContent then Inc(nl);
          hasContent := False; hasAny := False;
        end
        else
        begin
          hasAny := True;
          if lo > $20 then hasContent := True;
        end;
      end;
    end;
    firstBlock := False;
  until got < COUNT_BLOCK;
  if total = 0 then Exit;
  if hasAny then
    if (not skip) or hasContent then Inc(nl);
  Result := nl;
end;

// Establish file metadata (size, mtime, encoding) for fn. If the file changed
// since the last call, all lazily-built result groups are invalidated.
// Assumes CacheCS is held.
procedure EnsureMeta(h: THandle; const fn: WideString; sz, mt: Int64);
var
  bomLen: Integer;
begin
  if CacheValid and (CacheName = fn) and (CacheSize = sz) and (CacheTime = mt) then
    Exit;                                  // unchanged - keep existing results

  ResetResults;
  CacheName := fn;
  CacheSize := sz;
  CacheTime := mt;
  CacheFileEnc := encAnsi;
  CacheBomLen := 0;
  CacheLineIsUtf8 := False;
  CacheValid := True;

  if sz <= 0 then
  begin
    // empty file: nothing to read, every group is valid and empty
    CacheHead := '';
    CacheKind := fkText;
    CacheKindValid := True;
    CacheFirstValid := True;
    CacheLastValid := True;
    CacheLineCountValid := True;
    Exit;
  end;

  CacheHead := ReadChunk(h, 0, ClampLen(sz, CHUNK_SIZE));
  CacheFileEnc := DetectEnc(CacheHead, bomLen);
  CacheBomLen := bomLen;
  CacheLineIsUtf8 := CacheFileEnc <> encAnsi;
end;

// Lazily build the first up to MAX_FIRST lines. Assumes CacheCS is held.
procedure EnsureFirst(h: THandle);
var
  raw, buf: AnsiString;
begin
  if CacheFirstValid then Exit;
  raw := CacheHead;
  // ANSI and BOM-less UTF-8 need no transformation. Sharing the cached head
  // avoids copying up to 64 KiB on the common first-line query path.
  if (CacheBomLen = 0) and (CacheFileEnc in [encAnsi, encUtf8]) then
    buf := raw
  else
    buf := ProcessChunk(raw, CacheFileEnc, CacheBomLen);
  ParseFirst(buf, Int64(Length(raw)) >= CacheSize);
  // A blank-heavy (or very long-lined) head may not hold MAX_FIRST lines; widen.
  if (CacheFirstCount < MAX_FIRST) and (Int64(CHUNK_SIZE) < CacheSize) then
  begin
    raw := ReadChunk(h, 0, ClampLen(CacheSize, TAIL_MAX));
    buf := ProcessChunk(raw, CacheFileEnc, CacheBomLen);
    ParseFirst(buf, Int64(Length(raw)) >= CacheSize);
  end;
  CacheFirstValid := True;
end;

// Lazily build the last up to TAIL_FIELDS lines. Assumes CacheCS is held.
procedure EnsureLast(h: THandle);
var
  raw, tail: AnsiString;
  want, bl: Integer;
  ofs: Int64;
begin
  if CacheLastValid then Exit;
  want := ClampLen(CacheSize, CHUNK_SIZE);
  ofs := CacheSize - want;
  if ofs = 0 then bl := CacheBomLen else bl := 0;   // BOM only when tail = whole file
  raw := ReadChunk(h, ofs, want);
  tail := ProcessChunk(raw, CacheFileEnc, bl);
  ParseLast(tail, ofs = 0);
  // Too few (non-blank) lines in the tail window: widen towards the file start.
  if (CacheLastCount < TAIL_FIELDS) and (Int64(CHUNK_SIZE) < CacheSize) then
  begin
    want := ClampLen(CacheSize, TAIL_MAX);
    ofs := CacheSize - want;
    if ofs = 0 then bl := CacheBomLen else bl := 0;
    raw := ReadChunk(h, ofs, want);
    tail := ProcessChunk(raw, CacheFileEnc, bl);
    ParseLast(tail, ofs = 0);
  end;
  CacheLastValid := True;
end;

// Lazily count all lines. Assumes CacheCS is held.
procedure EnsureCount(h: THandle);
begin
  if CacheLineCountValid then Exit;
  CacheLineCount := CountLinesStream(h, CacheFileEnc, CacheBomLen, fSkip);
  CacheLineCountValid := True;
end;

//==============================================================
// Values
//==============================================================
function ContentGetValue(fn: pAnsiChar;
  FieldIndex, UnitIndex: integer;
  FieldValue: PAnsiChar;
  MaxLen, Flags: integer): integer; stdcall;
begin
  // Force Total Commander to use the wide version.
  Result := ft_fieldempty;
end;

function ContentGetValueW(fn: pWideChar;
  FieldIndex, UnitIndex: integer;
  FieldValue: PWideChar;
  MaxLen, Flags: integer): integer; stdcall;
var
  s, choice: AnsiString;
  ext: WideString;
  ws: WideString;
  n, need: Integer;
  found: Boolean;
  h: THandle;
  sz, mt: Int64;
  attrs: DWORD;
  ftc, fta, ftw: TFileTime;
begin
  if (FieldIndex < 0) or (FieldIndex > MAX_FIELD) then
    begin Result := FT_NOSUCHFIELD; Exit end;

  Result := FT_FIELDEMPTY;

  // Metadata fields deliberately bypass the text extension filter.
  if FieldIndex >= IDX_ENCODING then
  begin
    attrs := GetFileAttributesW(fn);
    if attrs = INVALID_FILE_ATTRIBUTES then begin Result := FT_FILEERROR; Exit end;
    if (attrs and FILE_ATTRIBUTE_DIRECTORY) <> 0 then
    begin
      if FieldIndex = IDX_TYPE then
      begin
        lstrcpynA(PAnsiChar(FieldValue), 'Folder', MaxLen);
        Result := FT_MULTIPLECHOICE;
      end;
      Exit;
    end;
  end
  else
  begin
    ext := LowerCase(ExtractFileExt(WideString(fn)));
    if (ext = '') then ext := '.';
    if (Pos('.', ext) = 1) then Delete(ext, 1, 1);
    if (fExt <> '') and (Pos(' ' + ext + ' ', ' ' + fExt + ' ') = 0) then
      begin Result := FT_FILEERROR; Exit end;
  end;

  EnterCriticalSection(CacheCS);
  try
    h := OpenRead(fn);
    if h = INVALID_HANDLE_VALUE then begin CacheValid := False; Exit end;
    try
      sz := FileSeek(h, Int64(0), 2);     // size via seek-to-end
      mt := 0;
      if GetFileTime(h, @ftc, @fta, @ftw) then
        mt := (Int64(ftw.dwHighDateTime) shl 32) or Cardinal(ftw.dwLowDateTime);

      EnsureMeta(h, fn, sz, mt);

      // Full encoding classification is performed only for this field and
      // uses CacheHead; no additional read or open is needed.
      if FieldIndex = IDX_ENCODING then
      begin
        EnsureEncoding;
        lstrcpynA(PAnsiChar(FieldValue), PAnsiChar(CacheEncoding), MaxLen);
        Result := FT_MULTIPLECHOICE;
        Exit;
      end;

      if FieldIndex = IDX_TYPE then
      begin
        EnsureKind;
        if CacheKind = fkBinary then choice := 'Binary' else choice := 'Text';
        lstrcpynA(PAnsiChar(FieldValue), PAnsiChar(choice), MaxLen);
        Result := FT_MULTIPLECHOICE;
        Exit;
      end;

      if FieldIndex = IDX_EOL then
      begin
        EnsureEol;
        if CacheEol <> '' then
        begin
          lstrcpynA(PAnsiChar(FieldValue), PAnsiChar(CacheEol), MaxLen);
          Result := FT_MULTIPLECHOICE;
        end;
        Exit;
      end;

      // numeric: line count
      if FieldIndex = IDX_COUNT then
      begin
        EnsureCount(h);
        PInt64(FieldValue)^ := CacheLineCount;
        Result := FT_NUMERIC_64;
        Exit;
      end;

      found := False;
      s := '';
      if FieldIndex < MAX_FIRST then
      begin
        EnsureFirst(h);
        if FieldIndex < CacheFirstCount then
        begin
          s := CacheFirst[FieldIndex];
          found := True;
        end;
      end
      else
      begin
        EnsureLast(h);
        need := IDX_COUNT - FieldIndex;          // 10->3, 11->2, 12->1
        if CacheLastCount >= need then
        begin
          s := CacheLast[CacheLastCount - need];
          found := True;
        end;
      end;
    finally
      CloseHandle(h);
    end;

    if not found then Exit;                      // -> FT_FIELDEMPTY

    s := Trim(s);

    if s <> '' then
    begin
      if CacheLineIsUtf8 then
        ws := AnsiToWide(s, cpUTF8)
      else if UnitIndex = 1 then
        ws := AnsiToWide(s, cpOEMCP)             // "dos" unit
      else
        ws := AnsiToWide(s, cpACP);              // "win" unit

      for n := Low(fReplaces) to High(fReplaces) do
        ReplaceAllW(ws, fReplaces[n].sFrom, fReplaces[n].sTo);

      if ws <> '' then
      begin
        lstrcpynW(FieldValue, PWideChar(ws), MaxLen);
        Result := FT_STRINGW;
      end;
    end;
  finally
    LeaveCriticalSection(CacheCS);
  end;
end;

exports
  ContentGetSupportedField,
  ContentGetValue,
  ContentGetValueW;

{$R *.res}

begin
  InitializeCriticalSection(CacheCS);
  Init;
end.
