library TextLine;

{$mode delphi}{$H+}

// Text Line - Content (WDX) plugin for Total Commander.
// Original by Alexey Fomin. Ported to Lazarus/FPC (32/64 bit) and extended:
//   * fields for the 3rd-last, 2nd-last and last line
//   * a numeric "Line count" field
//   * proper Unicode handling: UTF-8 and UTF-16 (LE/BE), with or without BOM,
//     plus legacy single-byte ANSI/OEM via the win|dos unit.
//
// Build:
//   - Open TextLine.lpi in Lazarus, pick build mode "Win32" -> TextLine.wdx
//     or "Win64" -> TextLine.wdx64, then Run > Build.

uses
  Windows,
  SysUtils,
  ContPlug,
  SProc;

const
  MAX_FIRST   = 10;        // fields 0..9   -> line 1..10
  TAIL_FIELDS = 3;         // fields 10..12 -> 3rd-last, 2nd-last, last line
  IDX_COUNT   = MAX_FIRST + TAIL_FIELDS;       // field 13 -> line count
  MAX_FIELD   = IDX_COUNT;                      // = 13

  WHOLE_LIMIT = 1 shl 20;      // <=1 MB: read the whole file in one go
  CHUNK_SIZE  = 1 shl 16;      // 64 KB head/tail chunk for big files
  TAIL_MAX    = 4 shl 20;      // cap when escalating tail reads
  COUNT_BLOCK = 1 shl 20;      // 1 MB streaming block for the line counter

  cpACP   = 0;       // system ANSI code page
  cpOEMCP = 1;       // system OEM (DOS) code page
  cpUTF8  = 65001;

type
  TEnc = (encAnsi, encUtf8, encUtf16LE, encUtf16BE);

var
  // --- settings (loaded once in Init) ---
  fnIni: string;
  fExt: string;
  fSkip: boolean;
  fReplaces: array[1..20] of
    record sFrom, sTo: string; end;

  // --- per-file cache (one entry, guarded by CacheCS) ---
  CacheCS: TRTLCriticalSection;
  CacheValid: Boolean = False;
  CacheName: WideString;
  CacheSize: Int64;
  CacheTime: Int64;
  CacheFileEnc: TEnc;          // detected encoding of the file
  CacheLineIsUtf8: Boolean;    // True -> stored line bytes are UTF-8, else raw ANSI/OEM
  // line text is stored as byte strings: UTF-8 for Unicode files, raw bytes for ANSI
  CacheFirst: array[0..MAX_FIRST-1] of AnsiString;
  CacheFirstCount: Integer;
  CacheLast: array[0..TAIL_FIELDS-1] of AnsiString; // oldest..newest of the last lines
  CacheLastCount: Integer;
  CacheLineCount: Int64;
  CacheLineCountValid: Boolean;

//==============================================================
// Field descriptions
//==============================================================
function ContentGetSupportedField(FieldIndex: integer;
  FieldName, Units: pAnsiChar;
  maxlen: integer): integer; stdcall;
const
  cTailNames: array[0..TAIL_FIELDS-1] of AnsiString =
    ('-3', '-2', '-1');
var
  nm: AnsiString;
begin
  if (FieldIndex < 0) or (FieldIndex > MAX_FIELD) then
    begin Result := FT_NOMOREFIELDS; Exit end;

  if FieldIndex = IDX_COUNT then
  begin
    lstrcpynA(FieldName, 'Line count', MaxLen);
    lstrcpynA(Units, '', MaxLen);
    Result := FT_NUMERIC_64;
    Exit;
  end;

  if FieldIndex < MAX_FIRST then
    nm := IntToStr(FieldIndex + 1)               // "1".."10"
  else
    nm := cTailNames[FieldIndex - MAX_FIRST];

  lstrcpynA(FieldName, PAnsiChar(nm), MaxLen);
  lstrcpynA(Units, 'win|dos', MaxLen);
  Result := FT_STRINGW;
end;

//==============================================================
// Settings
//==============================================================
function GetModuleFile: string;
var
  buf: array[0..MAX_PATH] of WideChar;
begin
  if GetModuleFileNameW(HINST(HInstance), @buf[0], MAX_PATH) > 0 then
    Result := string(WideString(PWideChar(@buf[0])))
  else
    Result := '';
end;

procedure Init;
var
  n: Integer;
  s, fnMod, fnEx: string;
begin
  fnMod := GetModuleFile;
  fnIni := ChangeFileExt(fnMod, '.ini');
  fnEx  := ChangeFileExt(fnMod, '.example.ini');
  if FileExists(fnEx) and not FileExists(fnIni) then
    CopyFile(PChar(fnEx), PChar(fnIni), true);

  fExt  := GetIniKey('Options', 'Extensions', '', fnIni);
  fSkip := (GetIniKey('Options', 'SkipEmpty', '0', fnIni) <> '0');
  for n := Low(fReplaces) to High(fReplaces) do
  begin
    s := GetIniKey('Replaces', 'S' + IntToStr(n), '=', fnIni);
    fReplaces[n].sFrom := Copy(s, 1, Pos('=', s) - 1);
    fReplaces[n].sTo   := Copy(s, Pos('=', s) + 1, MaxInt);
  end;
end;

//==============================================================
// Encoding helpers
//==============================================================
function AnsiToWide(const s: AnsiString; cp: UINT): WideString;
var n: Integer;
begin
  Result := '';
  if s = '' then Exit;
  n := MultiByteToWideChar(cp, 0, PAnsiChar(s), Length(s), nil, 0);
  if n <= 0 then Exit;
  SetLength(Result, n);
  MultiByteToWideChar(cp, 0, PAnsiChar(s), Length(s), PWideChar(Result), n);
end;

function WideToUtf8(const ws: UnicodeString): AnsiString;
var n: Integer;
begin
  Result := '';
  if ws = '' then Exit;
  n := WideCharToMultiByte(cpUTF8, 0, PWideChar(ws), Length(ws), nil, 0, nil, nil);
  if n <= 0 then Exit;
  SetLength(Result, n);
  WideCharToMultiByte(cpUTF8, 0, PWideChar(ws), Length(ws), PAnsiChar(Result), n, nil, nil);
end;

// Convert raw UTF-16 bytes (optionally byte-swapped for BE) to UTF-8 bytes.
function Utf16ToUtf8(const buf: AnsiString; be: Boolean; bomLen: Integer): AnsiString;
var
  ws: UnicodeString;
  n, i: Integer;
begin
  n := (Length(buf) - bomLen) div 2;
  if n <= 0 then begin Result := ''; Exit end;
  SetLength(ws, n);
  Move(buf[bomLen + 1], ws[1], n * 2);
  if be then
    for i := 1 to n do
      ws[i] := WideChar(Swap(Word(ws[i])));
  Result := WideToUtf8(ws);
end;

function LooksUtf8(const buf: AnsiString): Boolean;
var
  i, L, cont: Integer;
  b: Byte;
  hasMulti: Boolean;
begin
  L := Length(buf);
  i := 1;
  hasMulti := False;
  while i <= L do
  begin
    b := Byte(buf[i]);
    if b < $80 then
      cont := 0
    else if (b and $E0) = $C0 then begin cont := 1; hasMulti := True end
    else if (b and $F0) = $E0 then begin cont := 2; hasMulti := True end
    else if (b and $F8) = $F0 then begin cont := 3; hasMulti := True end
    else begin Result := False; Exit end;     // invalid lead byte
    Inc(i);
    while cont > 0 do
    begin
      if i > L then begin Result := hasMulti; Exit end;  // truncated at chunk edge
      if (Byte(buf[i]) and $C0) <> $80 then begin Result := False; Exit end;
      Inc(i); Dec(cont);
    end;
  end;
  Result := hasMulti;
end;

function LooksUtf16(const buf: AnsiString; out be: Boolean): Boolean;
var
  k, L, lim, zEven, zOdd: Integer;
begin
  be := False;
  L := Length(buf);
  lim := L; if lim > 4096 then lim := 4096;
  zEven := 0; zOdd := 0;
  for k := 0 to lim - 1 do
    if buf[k + 1] = #0 then
      if (k and 1) = 1 then Inc(zOdd) else Inc(zEven);
  // text encoded as UTF-16 has roughly every other byte = 0
  if (zEven + zOdd) > (lim div 8) then
  begin
    be := zOdd < zEven;        // LE -> zeros on odd byte index, BE -> on even
    Result := True;
  end
  else
    Result := False;
end;

function DetectEnc(const buf: AnsiString; out bomLen: Integer): TEnc;
var
  L: Integer;
  be: Boolean;
begin
  bomLen := 0;
  L := Length(buf);
  if (L >= 3) and (Byte(buf[1]) = $EF) and (Byte(buf[2]) = $BB) and (Byte(buf[3]) = $BF) then
    begin bomLen := 3; Result := encUtf8; Exit end;
  if (L >= 2) and (Byte(buf[1]) = $FF) and (Byte(buf[2]) = $FE) then
    begin bomLen := 2; Result := encUtf16LE; Exit end;
  if (L >= 2) and (Byte(buf[1]) = $FE) and (Byte(buf[2]) = $FF) then
    begin bomLen := 2; Result := encUtf16BE; Exit end;
  if LooksUtf16(buf, be) then
  begin
    if be then Result := encUtf16BE else Result := encUtf16LE;
    Exit;
  end;
  if LooksUtf8(buf) then begin Result := encUtf8; Exit end;
  Result := encAnsi;
end;

// Turn a raw byte chunk into the stored line representation:
// UTF-8 bytes for any Unicode file, raw bytes for ANSI. bomLen is only
// non-zero for the head/whole chunk (the tail never carries a BOM).
function ProcessChunk(const raw: AnsiString; enc: TEnc; bomLen: Integer): AnsiString;
begin
  case enc of
    encUtf16LE: Result := Utf16ToUtf8(raw, False, bomLen);
    encUtf16BE: Result := Utf16ToUtf8(raw, True, bomLen);
    encUtf8:    Result := Copy(raw, bomLen + 1, MaxInt);
  else
    Result := Copy(raw, bomLen + 1, MaxInt);   // ANSI (bomLen = 0)
  end;
end;

//==============================================================
// Line extraction (byte level on processed UTF-8/ANSI buffers;
// newline 0x0A never occurs inside a UTF-8 multibyte sequence)
//==============================================================
procedure StripCR(var s: AnsiString); inline;
begin
  if (s <> '') and (s[Length(s)] = #13) then
    SetLength(s, Length(s) - 1);
end;

function NewlineCount(const buf: AnsiString): Integer;
var i, L: Integer;
begin
  Result := 0;
  L := Length(buf);
  for i := 1 to L do
    if buf[i] = #10 then Inc(Result);
end;

// A line is "empty" (for SkipEmpty) when it holds only blank bytes, i.e. the
// same characters Trim removes (<= #32). Works on UTF-8 too: any non-ASCII
// byte is >= $80 and therefore counts as content.
function IsBlank(const s: AnsiString): Boolean;
var i: Integer;
begin
  for i := 1 to Length(s) do
    if Byte(s[i]) > $20 then begin Result := False; Exit end;
  Result := True;
end;

procedure ResetCache;
var i: Integer;
begin
  CacheFirstCount := 0;
  CacheLastCount := 0;
  for i := 0 to MAX_FIRST-1 do CacheFirst[i] := '';
  for i := 0 to TAIL_FIELDS-1 do CacheLast[i] := '';
end;

procedure ParseFirst(const buf: AnsiString; complete: Boolean);
var
  i, L, start, cnt: Integer;
  line: AnsiString;
begin
  L := Length(buf);
  cnt := 0;
  start := 1;
  i := 1;
  while (i <= L) and (cnt < MAX_FIRST) do
  begin
    if buf[i] = #10 then
    begin
      line := Copy(buf, start, i - start);
      StripCR(line);
      if not (fSkip and IsBlank(line)) then
      begin
        CacheFirst[cnt] := line;
        Inc(cnt);
      end;
      start := i + 1;
    end;
    Inc(i);
  end;
  if complete and (cnt < MAX_FIRST) and (start <= L) then
  begin
    line := Copy(buf, start, L - start + 1);
    StripCR(line);
    if not (fSkip and IsBlank(line)) then
    begin
      CacheFirst[cnt] := line;
      Inc(cnt);
    end;
  end;
  CacheFirstCount := cnt;
end;

procedure ParseLast(const buf: AnsiString);
var
  i, L, start, total, n, avail: Integer;
  arr: array of AnsiString;
begin
  L := Length(buf);
  if L = 0 then begin CacheLastCount := 0; Exit end;

  total := NewlineCount(buf) + 1;
  SetLength(arr, total);
  n := 0;
  start := 1;
  for i := 1 to L do
    if buf[i] = #10 then
    begin
      arr[n] := Copy(buf, start, i - start);
      StripCR(arr[n]);
      Inc(n);
      start := i + 1;
    end;
  arr[n] := Copy(buf, start, L - start + 1);
  StripCR(arr[n]);

  // a final newline yields a trailing empty segment - drop it
  if (total > 1) and (arr[total-1] = '') and (buf[L] = #10) then
    Dec(total);

  // SkipEmpty: keep only non-blank lines, counted from the bottom
  if fSkip then
  begin
    n := 0;
    for i := 0 to total - 1 do
      if not IsBlank(arr[i]) then
      begin
        arr[n] := arr[i];
        Inc(n);
      end;
    total := n;
  end;

  if total > TAIL_FIELDS then avail := TAIL_FIELDS else avail := total;
  for i := 0 to avail - 1 do
    CacheLast[i] := arr[total - avail + i];
  CacheLastCount := avail;
end;

//==============================================================
// File reading
//==============================================================
function OpenRead(const fn: WideString): THandle;
begin
  Result := CreateFileW(PWideChar(fn), GENERIC_READ,
    FILE_SHARE_READ or FILE_SHARE_WRITE or FILE_SHARE_DELETE,
    nil, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, 0);
end;

function ReadChunk(h: THandle; ofs: Int64; count: Integer): AnsiString;
var got: Integer;
begin
  Result := '';
  if count <= 0 then Exit;
  SetLength(Result, count);
  FileSeek(h, ofs, 0);
  got := FileRead(h, Result[1], count);
  if got < 0 then got := 0;
  if got < count then SetLength(Result, got);
end;

function ReadTail(h: THandle; sz: Int64; want: Integer): AnsiString;
begin
  if want > sz then want := sz;
  Result := ReadChunk(h, sz - want, want);
end;

// Count lines in a processed (UTF-8/ANSI) buffer. With skip, blank lines are
// not counted. A trailing newline does not add a phantom empty line.
function LineCountFromBuf(const buf: AnsiString; skip: Boolean): Int64;
var
  i, L: Integer;
  nl: Int64;
  b: Byte;
  hasContent, hasAny: Boolean;
begin
  L := Length(buf);
  if L = 0 then begin Result := 0; Exit end;
  nl := 0; hasContent := False; hasAny := False;
  for i := 1 to L do
  begin
    b := Byte(buf[i]);
    if b = 10 then
    begin
      if (not skip) or hasContent then Inc(nl);
      hasContent := False; hasAny := False;
    end
    else
    begin
      hasAny := True;
      if b > $20 then hasContent := True;
    end;
  end;
  if hasAny then                      // final, unterminated line
    if (not skip) or hasContent then Inc(nl);
  Result := nl;
end;

// Whole-file line counter for big files (one sequential pass, encoding aware).
function CountLinesStream(const fn: WideString; enc: TEnc; skip: Boolean): Int64;
var
  h: THandle;
  raw: AnsiString;
  got, n, i: Integer;
  nl, total: Int64;
  hasContent, hasAny, be: Boolean;
  lo, hi, t: Byte;
  w: Word;
begin
  Result := 0;
  h := OpenRead(fn);
  if h = INVALID_HANDLE_VALUE then Exit;
  try
    nl := 0; total := 0; hasContent := False; hasAny := False;
    be := (enc = encUtf16BE);
    SetLength(raw, COUNT_BLOCK);
    repeat
      got := FileRead(h, raw[1], COUNT_BLOCK);
      if got <= 0 then Break;
      Inc(total, got);
      if enc in [encUtf16LE, encUtf16BE] then
      begin
        n := got div 2;
        for i := 0 to n - 1 do
        begin
          lo := Byte(raw[2*i + 1]); hi := Byte(raw[2*i + 2]);
          if be then begin t := lo; lo := hi; hi := t end;
          w := lo or (hi shl 8);
          if w = 10 then
          begin
            if (not skip) or hasContent then Inc(nl);
            hasContent := False; hasAny := False;
          end
          else
          begin
            hasAny := True;
            if w > $20 then hasContent := True;
          end;
        end;
      end
      else
      begin
        for i := 1 to got do
        begin
          lo := Byte(raw[i]);
          if lo = 10 then
          begin
            if (not skip) or hasContent then Inc(nl);
            hasContent := False; hasAny := False;
          end
          else
          begin
            hasAny := True;
            if lo > $20 then hasContent := True;
          end;
        end;
      end;
    until got < COUNT_BLOCK;
  finally
    CloseHandle(h);
  end;
  if total = 0 then Exit;
  if hasAny then
    if (not skip) or hasContent then Inc(nl);
  Result := nl;
end;

procedure BuildLines(h: THandle; sz: Int64);
var
  raw, buf, tail: AnsiString;
  enc: TEnc;
  bomLen, n: Integer;
begin
  ResetCache;
  CacheFileEnc := encAnsi;
  CacheLineIsUtf8 := False;
  CacheLineCount := 0;
  CacheLineCountValid := True;     // empty file => 0 lines
  if sz <= 0 then Exit;

  if sz <= WHOLE_LIMIT then
  begin
    raw := ReadChunk(h, 0, Integer(sz));
    enc := DetectEnc(raw, bomLen);
    CacheFileEnc := enc;
    CacheLineIsUtf8 := enc <> encAnsi;
    buf := ProcessChunk(raw, enc, bomLen);
    ParseFirst(buf, True);
    ParseLast(buf);
    CacheLineCount := LineCountFromBuf(buf, fSkip);
    CacheLineCountValid := True;
  end
  else
  begin
    // Head
    raw := ReadChunk(h, 0, CHUNK_SIZE);
    enc := DetectEnc(raw, bomLen);
    CacheFileEnc := enc;
    CacheLineIsUtf8 := enc <> encAnsi;
    buf := ProcessChunk(raw, enc, bomLen);
    ParseFirst(buf, False);
    // With SkipEmpty a blank-heavy head may not hold 10 non-empty lines; widen.
    if (CacheFirstCount < MAX_FIRST) and (CHUNK_SIZE < sz) then
    begin
      if sz < TAIL_MAX then n := Integer(sz) else n := TAIL_MAX;
      raw := ReadChunk(h, 0, n);
      buf := ProcessChunk(raw, enc, bomLen);
      ParseFirst(buf, Int64(Length(raw)) >= sz);
    end;

    // Tail (chunk starts at an even file offset, so UTF-16 stays aligned)
    raw := ReadTail(h, sz, CHUNK_SIZE);
    tail := ProcessChunk(raw, enc, 0);
    ParseLast(tail);
    if (CacheLastCount < TAIL_FIELDS) and (CHUNK_SIZE < sz) then
    begin
      raw := ReadTail(h, sz, TAIL_MAX);
      tail := ProcessChunk(raw, enc, 0);
      ParseLast(tail);
    end;

    // Line count is expensive for big files: compute it lazily on demand.
    CacheLineCountValid := False;
  end;
end;

// Refresh the cache for fn if needed. Assumes CacheCS is held.
procedure EnsureCache(const fn: WideString);
var
  h: THandle;
  sz, mt: Int64;
  ftc, fta, ftw: TFileTime;
begin
  h := OpenRead(fn);
  if h = INVALID_HANDLE_VALUE then
  begin
    CacheValid := False;
    Exit;
  end;
  try
    sz := FileSeek(h, Int64(0), 2);     // size via seek-to-end
    mt := 0;
    if GetFileTime(h, @ftc, @fta, @ftw) then
      mt := (Int64(ftw.dwHighDateTime) shl 32) or Cardinal(ftw.dwLowDateTime);

    if CacheValid and (CacheName = fn) and
       (CacheSize = sz) and (CacheTime = mt) then
      Exit;                              // still fresh - reuse

    BuildLines(h, sz);
    CacheName := fn;
    CacheSize := sz;
    CacheTime := mt;
    CacheValid := True;
  finally
    CloseHandle(h);
  end;
end;

//==============================================================
// Values
//==============================================================
function ContentGetValue(fn: pAnsiChar;
  FieldIndex, UnitIndex: integer;
  FieldValue: PAnsiChar;
  MaxLen, Flags: integer): integer; stdcall;
begin
  // Force Total Commander to use the wide version.
  Result := ft_fieldempty;
end;

function ContentGetValueW(fn: pWideChar;
  FieldIndex, UnitIndex: integer;
  FieldValue: PWideChar;
  MaxLen, Flags: integer): integer; stdcall;
var
  s, ext: AnsiString;
  ws: WideString;
  n, need: Integer;
  found: Boolean;
begin
  if (FieldIndex < 0) or (FieldIndex > MAX_FIELD) then
    begin Result := FT_NOSUCHFIELD; Exit end;

  // extension filter (same logic as the original)
  ext := LowerCase(ExtractFileExt(string(WideString(fn))));
  if (ext = '') then ext := '.';
  if (Pos('.', ext) = 1) then Delete(ext, 1, 1);
  if (fExt <> '') and (Pos(' ' + ext + ' ', ' ' + fExt + ' ') = 0) then
    begin Result := FT_FILEERROR; Exit end;

  Result := FT_FIELDEMPTY;

  EnterCriticalSection(CacheCS);
  try
    EnsureCache(fn);
    if not CacheValid then Exit;

    // numeric: line count
    if FieldIndex = IDX_COUNT then
    begin
      if not CacheLineCountValid then
      begin
        CacheLineCount := CountLinesStream(CacheName, CacheFileEnc, fSkip);
        CacheLineCountValid := True;
      end;
      PInt64(FieldValue)^ := CacheLineCount;
      Result := FT_NUMERIC_64;
      Exit;
    end;

    found := False;
    s := '';
    if FieldIndex < MAX_FIRST then
    begin
      if FieldIndex < CacheFirstCount then
      begin
        s := CacheFirst[FieldIndex];
        found := True;
      end;
    end
    else
    begin
      need := IDX_COUNT - FieldIndex;            // 10->3, 11->2, 12->1
      if CacheLastCount >= need then
      begin
        s := CacheLast[CacheLastCount - need];
        found := True;
      end;
    end;

    if not found then Exit;                      // -> FT_FIELDEMPTY

    s := Trim(s);

    for n := Low(fReplaces) to High(fReplaces) do
      if fReplaces[n].sFrom <> '' then
        SReplaceAll(s, fReplaces[n].sFrom, fReplaces[n].sTo);

    if s <> '' then
    begin
      if CacheLineIsUtf8 then
        ws := AnsiToWide(s, cpUTF8)
      else if UnitIndex = 1 then
        ws := AnsiToWide(s, cpOEMCP)             // "dos" unit
      else
        ws := AnsiToWide(s, cpACP);              // "win" unit

      if ws <> '' then
      begin
        lstrcpynW(FieldValue, PWideChar(ws), MaxLen);
        Result := FT_STRINGW;
      end;
    end;
  finally
    LeaveCriticalSection(CacheCS);
  end;
end;

exports
  ContentGetSupportedField,
  ContentGetValue,
  ContentGetValueW;

{$R *.res}

begin
  InitializeCriticalSection(CacheCS);
  Init;
end.
