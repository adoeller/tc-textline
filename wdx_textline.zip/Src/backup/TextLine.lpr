library TextLine;

{$mode delphi}{$H+}

// Text Line - Content (WDX) plugin for Total Commander.
// Original by Alexey Fomin. Ported to Lazarus/FPC (32/64 bit) and extended
// with fields for the third-last, second-last and last line of a text file.
//
// Build:
//   - Open TextLine.lpi in Lazarus, pick build mode "Win32" -> TextLine.wdx
//     or "Win64" -> TextLine.wdx64, then Run > Build.
//   - Or from a console:
//       fpc -O3 -Twin32 -Px86_64? ...  (see TextLine.lpi for the exact flags)

uses
  Windows,
  SysUtils,
  ContPlug,
  SProc;

const
  MAX_FIRST   = 10;        // fields 0..9  -> line 1..10
  TAIL_FIELDS = 3;         // fields 10..12 -> 3rd-last, 2nd-last, last line
  MAX_FIELD   = MAX_FIRST + TAIL_FIELDS - 1;  // = 12

  WHOLE_LIMIT = 1 shl 20;      // <=1 MB: read the whole file in one go
  CHUNK_SIZE  = 1 shl 16;      // 64 KB head/tail chunk for big files
  TAIL_MAX    = 4 shl 20;      // cap when escalating tail reads

var
  // --- settings (loaded once in Init) ---
  fnIni: string;
  fExt: string;
  fSkip: boolean;
  fReplaces: array[1..20] of
    record sFrom, sTo: string; end;

  // --- per-file cache (one entry, guarded by CacheCS) ---
  CacheCS: TRTLCriticalSection;
  CacheValid: Boolean = False;
  CacheName: WideString;
  CacheSize: Int64;
  CacheTime: Int64;
  CacheFirst: array[0..MAX_FIRST-1] of AnsiString;
  CacheFirstCount: Integer;
  CacheLast: array[0..TAIL_FIELDS-1] of AnsiString; // oldest..newest of the last lines
  CacheLastCount: Integer;

//==============================================================
// Field descriptions
//==============================================================
function ContentGetSupportedField(FieldIndex: integer;
  FieldName, Units: pAnsiChar;
  maxlen: integer): integer; stdcall;
const
  cTailNames: array[0..TAIL_FIELDS-1] of AnsiString =
    ('3rd last line', '2nd last line', 'Last line');
var
  nm: AnsiString;
begin
  if (FieldIndex < 0) or (FieldIndex > MAX_FIELD) then
    begin Result := FT_NOMOREFIELDS; Exit end;

  if FieldIndex < MAX_FIRST then
    nm := IntToStr(FieldIndex + 1)               // "1".."10"
  else
    nm := cTailNames[FieldIndex - MAX_FIRST];

  lstrcpynA(FieldName, PAnsiChar(nm), MaxLen);
  lstrcpynA(Units, 'win|dos', MaxLen);
  Result := FT_STRINGW;
end;

//==============================================================
// Settings
//==============================================================
function GetModuleFile: string;
var
  buf: array[0..MAX_PATH] of WideChar;
begin
  if GetModuleFileNameW(HINST(HInstance), @buf[0], MAX_PATH) > 0 then
    Result := string(WideString(PWideChar(@buf[0])))
  else
    Result := '';
end;

procedure Init;
var
  n: Integer;
  s, fnMod, fnEx: string;
begin
  fnMod := GetModuleFile;
  fnIni := ChangeFileExt(fnMod, '.ini');
  fnEx  := ChangeFileExt(fnMod, '.example.ini');
  if FileExists(fnEx) and not FileExists(fnIni) then
    CopyFile(PChar(fnEx), PChar(fnIni), true);

  fExt  := GetIniKey('Options', 'Extensions', '', fnIni);
  fSkip := (GetIniKey('Options', 'SkipEmpty', '0', fnIni) <> '0');
  for n := Low(fReplaces) to High(fReplaces) do
  begin
    s := GetIniKey('Replaces', 'S' + IntToStr(n), '=', fnIni);
    fReplaces[n].sFrom := Copy(s, 1, Pos('=', s) - 1);
    fReplaces[n].sTo   := Copy(s, Pos('=', s) + 1, MaxInt);
  end;
end;

//==============================================================
// Fast line extraction (raw bytes, treated as ANSI like the original)
//==============================================================
procedure StripCR(var s: AnsiString); inline;
begin
  if (s <> '') and (s[Length(s)] = #13) then
    SetLength(s, Length(s) - 1);
end;

function NewlineCount(const buf: AnsiString): Integer;
var i, L: Integer;
begin
  Result := 0;
  L := Length(buf);
  for i := 1 to L do
    if buf[i] = #10 then Inc(Result);
end;

procedure ResetCache;
var i: Integer;
begin
  CacheFirstCount := 0;
  CacheLastCount := 0;
  for i := 0 to MAX_FIRST-1 do CacheFirst[i] := '';
  for i := 0 to TAIL_FIELDS-1 do CacheLast[i] := '';
end;

// Fill CacheFirst from the start of the buffer.
// complete = the buffer reaches the end of the file (so a trailing
// segment without a final LF still counts as a line).
procedure ParseFirst(const buf: AnsiString; complete: Boolean);
var
  i, L, start, cnt: Integer;
  line: AnsiString;
begin
  L := Length(buf);
  cnt := 0;
  start := 1;
  i := 1;
  while (i <= L) and (cnt < MAX_FIRST) do
  begin
    if buf[i] = #10 then
    begin
      line := Copy(buf, start, i - start);
      StripCR(line);
      CacheFirst[cnt] := line;
      Inc(cnt);
      start := i + 1;
    end;
    Inc(i);
  end;
  // trailing line without final newline (only when we saw the whole file)
  if complete and (cnt < MAX_FIRST) and (start <= L) then
  begin
    line := Copy(buf, start, L - start + 1);
    StripCR(line);
    CacheFirst[cnt] := line;
    Inc(cnt);
  end;
  CacheFirstCount := cnt;
end;

// Fill CacheLast from the end of the buffer (the last up to TAIL_FIELDS lines).
procedure ParseLast(const buf: AnsiString);
var
  i, L, start, total, n, avail: Integer;
  arr: array of AnsiString;
begin
  L := Length(buf);
  if L = 0 then begin CacheLastCount := 0; Exit end;

  total := NewlineCount(buf) + 1;
  SetLength(arr, total);
  n := 0;
  start := 1;
  for i := 1 to L do
    if buf[i] = #10 then
    begin
      arr[n] := Copy(buf, start, i - start);
      StripCR(arr[n]);
      Inc(n);
      start := i + 1;
    end;
  arr[n] := Copy(buf, start, L - start + 1);
  StripCR(arr[n]);

  // A final newline produces a trailing empty segment - drop it so that
  // "last line" is the last content line (matches Readln semantics).
  if (total > 1) and (arr[total-1] = '') and (buf[L] = #10) then
    Dec(total);

  if total > TAIL_FIELDS then avail := TAIL_FIELDS else avail := total;
  for i := 0 to avail - 1 do
    CacheLast[i] := arr[total - avail + i];
  CacheLastCount := avail;
end;

function ReadChunk(h: THandle; ofs: Int64; count: Integer): AnsiString;
var got: Integer;
begin
  Result := '';
  if count <= 0 then Exit;
  SetLength(Result, count);
  FileSeek(h, ofs, 0);
  got := FileRead(h, Result[1], count);
  if got < 0 then got := 0;
  if got < count then SetLength(Result, got);
end;

function ReadTail(h: THandle; sz: Int64; want: Integer): AnsiString;
begin
  if want > sz then want := sz;
  Result := ReadChunk(h, sz - want, want);
end;

procedure BuildLines(h: THandle; sz: Int64);
var
  buf, tail: AnsiString;
begin
  ResetCache;
  if sz <= 0 then Exit;

  if sz <= WHOLE_LIMIT then
  begin
    buf := ReadChunk(h, 0, Integer(sz));
    ParseFirst(buf, True);
    ParseLast(buf);
  end
  else
  begin
    // Head: first 64 KB is far more than 10 lines for any real text file.
    buf := ReadChunk(h, 0, CHUNK_SIZE);
    ParseFirst(buf, False);

    // Tail: last 64 KB; escalate only if it does not hold 3 line breaks.
    tail := ReadTail(h, sz, CHUNK_SIZE);
    if NewlineCount(tail) < TAIL_FIELDS then
      tail := ReadTail(h, sz, TAIL_MAX);
    ParseLast(tail);
  end;
end;

// Refresh the cache for fn if needed. Assumes CacheCS is held.
procedure EnsureCache(const fn: WideString);
var
  h: THandle;
  sz, mt: Int64;
  ftc, fta, ftw: TFileTime;
begin
  h := CreateFileW(PWideChar(fn), GENERIC_READ,
        FILE_SHARE_READ or FILE_SHARE_WRITE or FILE_SHARE_DELETE,
        nil, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, 0);
  if h = INVALID_HANDLE_VALUE then
  begin
    CacheValid := False;
    Exit;
  end;
  try
    sz := FileSeek(h, Int64(0), 2);     // size via seek-to-end
    mt := 0;
    if GetFileTime(h, @ftc, @fta, @ftw) then
      mt := (Int64(ftw.dwHighDateTime) shl 32) or Cardinal(ftw.dwLowDateTime);

    if CacheValid and (CacheName = fn) and
       (CacheSize = sz) and (CacheTime = mt) then
      Exit;                              // still fresh - reuse

    BuildLines(h, sz);
    CacheName := fn;
    CacheSize := sz;
    CacheTime := mt;
    CacheValid := True;
  finally
    CloseHandle(h);
  end;
end;

//==============================================================
// Values
//==============================================================
function ContentGetValue(fn: pAnsiChar;
  FieldIndex, UnitIndex: integer;
  FieldValue: PAnsiChar;
  MaxLen, Flags: integer): integer; stdcall;
begin
  // Force Total Commander to use the wide version.
  Result := ft_fieldempty;
end;

function ContentGetValueW(fn: pWideChar;
  FieldIndex, UnitIndex: integer;
  FieldValue: PWideChar;
  MaxLen, Flags: integer): integer; stdcall;
var
  s, ext: AnsiString;
  ws: WideString;
  n, need: Integer;
  found: Boolean;
begin
  if (FieldIndex < 0) or (FieldIndex > MAX_FIELD) then
    begin Result := FT_NOSUCHFIELD; Exit end;

  // extension filter (same logic as the original)
  ext := LowerCase(ExtractFileExt(string(WideString(fn))));
  if (ext = '') then ext := '.';
  if (Pos('.', ext) = 1) then Delete(ext, 1, 1);
  if (fExt <> '') and (Pos(' ' + ext + ' ', ' ' + fExt + ' ') = 0) then
    begin Result := FT_FILEERROR; Exit end;

  Result := FT_FIELDEMPTY;

  EnterCriticalSection(CacheCS);
  try
    EnsureCache(fn);

    found := False;
    s := '';
    if FieldIndex < MAX_FIRST then
    begin
      if FieldIndex < CacheFirstCount then
      begin
        s := CacheFirst[FieldIndex];
        found := True;
      end;
    end
    else
    begin
      need := (MAX_FIELD + 1) - FieldIndex;     // 10->3, 11->2, 12->1
      if CacheLastCount >= need then
      begin
        s := CacheLast[CacheLastCount - need];
        found := True;
      end;
    end;

    if not found then Exit;                      // -> FT_FIELDEMPTY

    s := Trim(s);

    for n := Low(fReplaces) to High(fReplaces) do
      if fReplaces[n].sFrom <> '' then
        SReplaceAll(s, fReplaces[n].sFrom, fReplaces[n].sTo);

    if UnitIndex = 1 then
      s := ToANSI(s);

    if s <> '' then
    begin
      ws := WideString(s);
      lstrcpynW(FieldValue, PWideChar(ws), MaxLen);
      Result := FT_STRINGW;
    end;
  finally
    LeaveCriticalSection(CacheCS);
  end;
end;

exports
  ContentGetSupportedField,
  ContentGetValue,
  ContentGetValueW;

begin
  InitializeCriticalSection(CacheCS);
  Init;
end.
