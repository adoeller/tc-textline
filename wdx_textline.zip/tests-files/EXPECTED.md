# Expected detection results

| File | Encoding | Type |
|---|---|---|
| `empty.dat` | ANSI | Text |
| `ansi.txt` | ANSI | Text |
| `utf8-no-bom.txt` | UTF-8 no BOM | Text |
| `utf8-bom.txt` | UTF-8 BOM | Text |
| `utf16le-bom.txt` | UTF-16 LE | Text |
| `utf16le-no-bom.txt` | UTF-16 LE | Text |
| `utf16be-bom.txt` | UTF-16 BE | Text |
| `utf16be-no-bom.txt` | UTF-16 BE | Text |
| `sample.rtf` | RTF | Text |
| `binary-pe.bin` | Binary | Binary |
| `binary.zip` | Binary | Binary |
| `binary.png` | Binary | Binary |
| `binary.pdf` | Binary | Binary |
| `dos.bin` | DOS | Text |
| `ansi-ru.bin` | ANSI Ru | Text |
| `dos-ru.bin` | DOS Ru | Text |
