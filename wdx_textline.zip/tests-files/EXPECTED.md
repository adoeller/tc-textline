# Expected detection results

An em dash means that the field returns no value.

| File | Encoding | Type | Line ending |
|---|---|---|---|
| `empty.dat` | ANSI | Text | None |
| `ansi.txt` | ANSI | Text | None |
| `utf8-no-bom.txt` | UTF-8 no BOM | Text | None |
| `utf8-bom.txt` | UTF-8 BOM | Text | None |
| `utf16le-bom.txt` | UTF-16 LE | Text | None |
| `utf16le-no-bom.txt` | UTF-16 LE | Text | None |
| `utf16be-bom.txt` | UTF-16 BE | Text | None |
| `utf16be-no-bom.txt` | UTF-16 BE | Text | None |
| `sample.rtf` | RTF | Text | None |
| `binary-pe.bin` | Binary | Binary | — |
| `binary.zip` | Binary | Binary | — |
| `binary.png` | Binary | Binary | — |
| `binary.pdf` | Binary | Binary | — |
| `dos.bin` | DOS | Text | None |
| `ansi-ru.bin` | ANSI Ru | Text | None |
| `dos-ru.bin` | DOS Ru | Text | None |
| `eol-windows.txt` | ANSI | Text | Windows |
| `eol-unix.txt` | ANSI | Text | Unix |
| `eol-mac.txt` | ANSI | Text | Mac |
| `eol-mixed.txt` | ANSI | Text | Mixed |
| `eol-none.txt` | ANSI | Text | None |
| `eol-utf16le-windows.txt` | UTF-16 LE | Text | Windows |
| `eol-utf16be-unix.txt` | UTF-16 BE | Text | Unix |
