param(
  [Parameter(Mandatory = $true)]
  [string]$PluginPath
)

$ErrorActionPreference = 'Stop'

Add-Type @'
using System;
using System.Runtime.InteropServices;

public static class WdxNative {
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
  public static extern IntPtr LoadLibraryW(string path);

  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr GetProcAddress(IntPtr module, string name);

  [DllImport("kernel32.dll")]
  public static extern bool FreeLibrary(IntPtr module);

  [UnmanagedFunctionPointer(CallingConvention.StdCall)]
  public delegate int SupportedField(int index, IntPtr name, IntPtr units, int maxLen);

  [UnmanagedFunctionPointer(CallingConvention.StdCall, CharSet = CharSet.Unicode)]
  public delegate int GetValueW(IntPtr fileName, int fieldIndex, int unitIndex,
    IntPtr fieldValue, int maxLen, int flags);
}
'@

function Assert-Equal($Expected, $Actual, [string]$Message) {
  if ($Expected -ne $Actual) {
    throw "$Message`: expected '$Expected', got '$Actual'"
  }
}

$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('TextLine-test-' + [Guid]::NewGuid())
[IO.Directory]::CreateDirectory($tempRoot) | Out-Null
$testPlugin = Join-Path $tempRoot ([IO.Path]::GetFileName($PluginPath))
$testIni = [IO.Path]::ChangeExtension($testPlugin, '.ini')

try {
  [IO.File]::Copy((Resolve-Path $PluginPath), $testPlugin)
  $ini = @"
[Options]
Extensions=TXT
SkipEmpty=1
[Encoding]
TextBufferSizeKB=1
Utf8BufferSizeKB=64
OemEnabled=1
OemBufferSizeKB=1
OemPercent=18
OemIgnore=AB BB
RusEnabled=1
RusBufferSizeKB=2
RusMinSize=8
RusPercent=30
RusWordLen=0
[Replaces]
S1=Grüße=Änderung
S2=a=aa
"@
  [IO.File]::WriteAllText($testIni, $ini, [Text.Encoding]::Unicode)

  $utf8BomEmpty = Join-Path $tempRoot 'utf8-bom-empty.txt'
  [IO.File]::WriteAllBytes($utf8BomEmpty, [byte[]](0xEF, 0xBB, 0xBF, 0x0A))
  $utf8BomOnly = Join-Path $tempRoot 'utf8-bom-only.txt'
  [IO.File]::WriteAllBytes($utf8BomOnly, [byte[]](0xEF, 0xBB, 0xBF))
  $utf8 = Join-Path $tempRoot 'utf8.txt'
  [IO.File]::WriteAllText($utf8, 'Grüße', [Text.UTF8Encoding]::new($false))
  $utf16Le = Join-Path $tempRoot 'utf16le.txt'
  [IO.File]::WriteAllText($utf16Le, 'x', [Text.Encoding]::Unicode)
  $utf16LeNoBom = Join-Path $tempRoot 'utf16le-no-bom.txt'
  [IO.File]::WriteAllBytes($utf16LeNoBom, [Text.Encoding]::Unicode.GetBytes('x'))
  $utf16Be = Join-Path $tempRoot 'utf16be.txt'
  [IO.File]::WriteAllText($utf16Be, 'x', [Text.Encoding]::BigEndianUnicode)
  $utf16BeNoBom = Join-Path $tempRoot 'utf16be-no-bom.txt'
  [IO.File]::WriteAllBytes($utf16BeNoBom, [Text.Encoding]::BigEndianUnicode.GetBytes('x'))
  $ansi = Join-Path $tempRoot 'ansi.txt'
  [IO.File]::WriteAllBytes($ansi, [Text.Encoding]::ASCII.GetBytes('a'))
  $empty = Join-Path $tempRoot 'empty.dat'
  [IO.File]::WriteAllBytes($empty, [byte[]]@())
  $rtf = Join-Path $tempRoot 'sample.rtf'
  [IO.File]::WriteAllBytes($rtf, [Text.Encoding]::ASCII.GetBytes('{\rtf1 test}'))

  $binary = Join-Path $tempRoot 'binary.txt'
  [IO.File]::WriteAllBytes($binary, [byte[]](0x4D, 0x5A, 0x00, 0x01, 0x02, 0x03))
  $zip = Join-Path $tempRoot 'sample.zip'
  [IO.File]::WriteAllBytes($zip, [byte[]](0x50, 0x4B, 0x03, 0x04, 0x00, 0x00))
  $png = Join-Path $tempRoot 'sample.png'
  [IO.File]::WriteAllBytes($png, [byte[]](0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
  $pdf = Join-Path $tempRoot 'sample.pdf'
  [IO.File]::WriteAllBytes($pdf, [byte[]]([Text.Encoding]::ASCII.GetBytes("%PDF-1.7`n") + 0x00 + 0x01))

  $dos = Join-Path $tempRoot 'dos.bin'
  [IO.File]::WriteAllBytes($dos, [byte[]](0xB0, 0xB0, 0xB0, 0x41, 0x42, 0x43, 0x44, 0x45))
  $ansiRu = Join-Path $tempRoot 'ansi-ru.bin'
  [IO.File]::WriteAllBytes($ansiRu, [byte[]](0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9))
  $dosRu = Join-Path $tempRoot 'dos-ru.bin'
  [IO.File]::WriteAllBytes($dosRu, [byte[]](0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89))

  $module = [WdxNative]::LoadLibraryW($testPlugin)
  if ($module -eq [IntPtr]::Zero) {
    throw "LoadLibrary failed: $([Runtime.InteropServices.Marshal]::GetLastWin32Error())"
  }

  try {
    $supportedPtr = [WdxNative]::GetProcAddress($module, 'ContentGetSupportedField')
    $valuePtr = [WdxNative]::GetProcAddress($module, 'ContentGetValueW')
    if (($supportedPtr -eq [IntPtr]::Zero) -or ($valuePtr -eq [IntPtr]::Zero)) {
      throw 'Required WDX exports are missing'
    }
    $supported = [Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer(
      $supportedPtr, [type][WdxNative+SupportedField])
    $getValue = [Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer(
      $valuePtr, [type][WdxNative+GetValueW])

    $name = [Runtime.InteropServices.Marshal]::AllocHGlobal(256)
    $units = [Runtime.InteropServices.Marshal]::AllocHGlobal(256)
    $value = [Runtime.InteropServices.Marshal]::AllocHGlobal(2048)
    try {
      Assert-Equal 2 ($supported.Invoke(13, $name, $units, 256)) 'Line count field type'
      Assert-Equal 7 ($supported.Invoke(14, $name, $units, 256)) 'Encoding field type'
      Assert-Equal 'Encoding' ([Runtime.InteropServices.Marshal]::PtrToStringAnsi($name)) 'Encoding field name'
      Assert-Equal 7 ($supported.Invoke(15, $name, $units, 256)) 'Type field type'
      Assert-Equal 'Type' ([Runtime.InteropServices.Marshal]::PtrToStringAnsi($name)) 'Type field name'

      function Get-Text([string]$Path, [int]$Field) {
        $fileName = [Runtime.InteropServices.Marshal]::StringToHGlobalUni($Path)
        try {
          for ($i = 0; $i -lt 2048; $i++) { [Runtime.InteropServices.Marshal]::WriteByte($value, $i, 0) }
          $kind = $getValue.Invoke($fileName, $Field, 0, $value, 1024, 0)
          Assert-Equal 11 $kind "String field type for $Path"
          return [Runtime.InteropServices.Marshal]::PtrToStringUni($value)
        } finally {
          [Runtime.InteropServices.Marshal]::FreeHGlobal($fileName)
        }
      }

      function Get-Count([string]$Path) {
        $fileName = [Runtime.InteropServices.Marshal]::StringToHGlobalUni($Path)
        try {
          $kind = $getValue.Invoke($fileName, 13, 0, $value, 1024, 0)
          Assert-Equal 2 $kind "Numeric field type for $Path"
          return [Runtime.InteropServices.Marshal]::ReadInt64($value)
        } finally {
          [Runtime.InteropServices.Marshal]::FreeHGlobal($fileName)
        }
      }

      function Get-Choice([string]$Path, [int]$Field) {
        $fileName = [Runtime.InteropServices.Marshal]::StringToHGlobalUni($Path)
        try {
          for ($i = 0; $i -lt 2048; $i++) { [Runtime.InteropServices.Marshal]::WriteByte($value, $i, 0) }
          $kind = $getValue.Invoke($fileName, $Field, 0, $value, 1024, 0)
          Assert-Equal 7 $kind "Choice field type for $Path"
          return [Runtime.InteropServices.Marshal]::PtrToStringAnsi($value)
        } finally {
          [Runtime.InteropServices.Marshal]::FreeHGlobal($fileName)
        }
      }

      function Get-ResultKind([string]$Path, [int]$Field) {
        $fileName = [Runtime.InteropServices.Marshal]::StringToHGlobalUni($Path)
        try {
          return $getValue.Invoke($fileName, $Field, 0, $value, 1024, 0)
        } finally {
          [Runtime.InteropServices.Marshal]::FreeHGlobal($fileName)
        }
      }

      Assert-Equal 0 (Get-Count $utf8BomEmpty) 'BOM plus empty line with SkipEmpty'
      Assert-Equal 0 (Get-Count $utf8BomOnly) 'BOM-only line count'
      Assert-Equal 'UTF-8 BOM' (Get-Choice $utf8BomOnly 14) 'UTF-8 BOM detection'
      Assert-Equal 'UTF-8 no BOM' (Get-Choice $utf8 14) 'UTF-8 detection'
      Assert-Equal 'UTF-16 LE' (Get-Choice $utf16Le 14) 'UTF-16 LE detection'
      Assert-Equal 'UTF-16 LE' (Get-Choice $utf16LeNoBom 14) 'UTF-16 LE no-BOM detection'
      Assert-Equal 'UTF-16 BE' (Get-Choice $utf16Be 14) 'UTF-16 BE detection'
      Assert-Equal 'UTF-16 BE' (Get-Choice $utf16BeNoBom 14) 'UTF-16 BE no-BOM detection'
      Assert-Equal 'ANSI' (Get-Choice $ansi 14) 'ANSI detection'
      Assert-Equal 'ANSI' (Get-Choice $empty 14) 'Empty-file encoding'
      Assert-Equal 'RTF' (Get-Choice $rtf 14) 'RTF detection'
      Assert-Equal 'Binary' (Get-Choice $binary 14) 'Binary detection'
      Assert-Equal 'Binary' (Get-Choice $zip 14) 'ZIP detection'
      Assert-Equal 'Binary' (Get-Choice $png 14) 'PNG detection'
      Assert-Equal 'Binary' (Get-Choice $pdf 14) 'PDF binary detection'
      Assert-Equal 'DOS' (Get-Choice $dos 14) 'DOS detection'
      Assert-Equal 'ANSI Ru' (Get-Choice $ansiRu 14) 'ANSI Russian detection'
      Assert-Equal 'DOS Ru' (Get-Choice $dosRu 14) 'DOS Russian detection'

      Assert-Equal 'Folder' (Get-Choice $tempRoot 15) 'Folder type'
      Assert-Equal 'Text' (Get-Choice $utf8 15) 'UTF-8 text type'
      Assert-Equal 'Text' (Get-Choice $rtf 15) 'RTF text type'
      Assert-Equal 'Text' (Get-Choice $empty 15) 'Empty-file text type'
      Assert-Equal 'Binary' (Get-Choice $binary 15) 'Binary type'
      Assert-Equal -3 (Get-ResultKind $tempRoot 14) 'Folder has no encoding'
      Assert-Equal 'Änderung' (Get-Text $utf8 0) 'Unicode replacement'
      Assert-Equal 'aa' (Get-Text $ansi 0) 'Self-containing replacement terminates'
    } finally {
      [Runtime.InteropServices.Marshal]::FreeHGlobal($name)
      [Runtime.InteropServices.Marshal]::FreeHGlobal($units)
      [Runtime.InteropServices.Marshal]::FreeHGlobal($value)
    }
  } finally {
    [WdxNative]::FreeLibrary($module) | Out-Null
  }

  Write-Output "PASS $([IO.Path]::GetFileName($PluginPath))"
} finally {
  if ([IO.Directory]::Exists($tempRoot)) {
    [IO.Directory]::Delete($tempRoot, $true)
  }
}
