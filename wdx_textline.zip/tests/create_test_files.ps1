param(
  [string]$OutputDirectory = (Join-Path $PSScriptRoot '..\tests-files')
)

$ErrorActionPreference = 'Stop'
[IO.Directory]::CreateDirectory($OutputDirectory) | Out-Null

function Write-Bytes([string]$Name, [byte[]]$Bytes) {
  [IO.File]::WriteAllBytes((Join-Path $OutputDirectory $Name), $Bytes)
}

Write-Bytes 'empty.dat' ([byte[]]@())
Write-Bytes 'ansi.txt' ([Text.Encoding]::ASCII.GetBytes('plain ANSI text'))
Write-Bytes 'utf8-no-bom.txt' ([Text.UTF8Encoding]::new($false).GetBytes('Grüße'))
Write-Bytes 'utf8-bom.txt' ([byte[]](0xEF, 0xBB, 0xBF) + [Text.UTF8Encoding]::new($false).GetBytes('Grüße'))
Write-Bytes 'utf16le-bom.txt' ([Text.Encoding]::Unicode.GetPreamble() + [Text.Encoding]::Unicode.GetBytes('text'))
Write-Bytes 'utf16le-no-bom.txt' ([Text.Encoding]::Unicode.GetBytes('text'))
Write-Bytes 'utf16be-bom.txt' ([Text.Encoding]::BigEndianUnicode.GetPreamble() + [Text.Encoding]::BigEndianUnicode.GetBytes('text'))
Write-Bytes 'utf16be-no-bom.txt' ([Text.Encoding]::BigEndianUnicode.GetBytes('text'))
Write-Bytes 'sample.rtf' ([Text.Encoding]::ASCII.GetBytes('{\rtf1 test}'))
Write-Bytes 'binary-pe.bin' ([byte[]](0x4D, 0x5A, 0x00, 0x01, 0x02, 0x03))
Write-Bytes 'binary.zip' ([byte[]](0x50, 0x4B, 0x03, 0x04, 0x00, 0x00))
Write-Bytes 'binary.png' ([byte[]](0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A))
Write-Bytes 'binary.pdf' ([byte[]]([Text.Encoding]::ASCII.GetBytes("%PDF-1.7`n") + 0x00 + 0x01))
Write-Bytes 'dos.bin' ([byte[]](0xB0, 0xB0, 0xB0, 0x41, 0x42, 0x43, 0x44, 0x45))
Write-Bytes 'ansi-ru.bin' ([byte[]](0xC0, 0xC1, 0xC2, 0xC3, 0xC4, 0xC5, 0xC6, 0xC7, 0xC8, 0xC9))
Write-Bytes 'dos-ru.bin' ([byte[]](0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89))

Write-Bytes 'eol-windows.txt' ([Text.Encoding]::ASCII.GetBytes("one`r`ntwo`r`n"))
Write-Bytes 'eol-unix.txt' ([Text.Encoding]::ASCII.GetBytes("one`ntwo`n"))
Write-Bytes 'eol-mac.txt' ([Text.Encoding]::ASCII.GetBytes("one`rtwo`r"))
Write-Bytes 'eol-mixed.txt' ([Text.Encoding]::ASCII.GetBytes("one`r`ntwo`nthree`r"))
Write-Bytes 'eol-none.txt' ([Text.Encoding]::ASCII.GetBytes('one line'))
Write-Bytes 'eol-utf16le-windows.txt' ([Text.Encoding]::Unicode.GetPreamble() +
  [Text.Encoding]::Unicode.GetBytes("one`r`ntwo"))
Write-Bytes 'eol-utf16be-unix.txt' ([Text.Encoding]::BigEndianUnicode.GetBytes("one`ntwo"))

Write-Output "Created encoding, binary, and line-ending fixtures in $([IO.Path]::GetFullPath($OutputDirectory))"
