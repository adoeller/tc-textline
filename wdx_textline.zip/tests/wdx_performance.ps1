param(
  [Parameter(Mandatory = $true)] [string]$BaselinePlugin,
  [Parameter(Mandatory = $true)] [string]$CurrentPlugin,
  [int]$FileCount = 300,
  [int]$Rounds = 7
)

$ErrorActionPreference = 'Stop'

Add-Type @'
using System;
using System.Runtime.InteropServices;
public static class WdxPerfNative {
  [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
  public static extern IntPtr LoadLibraryW(string path);
  [DllImport("kernel32.dll", SetLastError = true)]
  public static extern IntPtr GetProcAddress(IntPtr module, string name);
  [DllImport("kernel32.dll")]
  public static extern bool FreeLibrary(IntPtr module);
  [UnmanagedFunctionPointer(CallingConvention.StdCall)]
  public delegate int GetValueW(IntPtr fileName, int fieldIndex, int unitIndex,
    IntPtr fieldValue, int maxLen, int flags);
}
'@

function Get-Median([double[]]$Values) {
  $sorted = $Values | Sort-Object
  return $sorted[[int][Math]::Floor($sorted.Count / 2)]
}

$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('TextLine-perf-' + [Guid]::NewGuid())
[IO.Directory]::CreateDirectory($tempRoot) | Out-Null

try {
  $baselineCopy = Join-Path $tempRoot 'baseline.wdx64'
  $currentCopy = Join-Path $tempRoot 'current.wdx64'
  [IO.File]::Copy((Resolve-Path $BaselinePlugin), $baselineCopy)
  [IO.File]::Copy((Resolve-Path $CurrentPlugin), $currentCopy)
  $ini = "[Options]`r`nExtensions=txt`r`nSkipEmpty=0`r`n"
  [IO.File]::WriteAllText([IO.Path]::ChangeExtension($baselineCopy, '.ini'), $ini)
  [IO.File]::WriteAllText([IO.Path]::ChangeExtension($currentCopy, '.ini'), $ini)

  $files = New-Object string[] $FileCount
  $line = [Text.Encoding]::UTF8.GetBytes(('performance test line ' + ('x' * 100) + "`n"))
  $data = New-Object byte[] 65536
  for ($i = 0; $i -lt $data.Length; $i++) { $data[$i] = $line[$i % $line.Length] }
  for ($i = 0; $i -lt $FileCount; $i++) {
    $files[$i] = Join-Path $tempRoot ('fixture-{0:D4}.txt' -f $i)
    [IO.File]::WriteAllBytes($files[$i], $data)
  }
  # Warm only the OS cache; each DLL still sees a different filename on every call.
  foreach ($file in $files) { [void][IO.File]::ReadAllBytes($file) }

  function Load-Plugin([string]$Path) {
    $module = [WdxPerfNative]::LoadLibraryW($Path)
    if ($module -eq [IntPtr]::Zero) { throw "LoadLibrary failed for $Path" }
    $ptr = [WdxPerfNative]::GetProcAddress($module, 'ContentGetValueW')
    if ($ptr -eq [IntPtr]::Zero) { throw "ContentGetValueW missing in $Path" }
    return @($module, [Runtime.InteropServices.Marshal]::GetDelegateForFunctionPointer(
      $ptr, [type][WdxPerfNative+GetValueW]))
  }

  $baselineLoaded = Load-Plugin $baselineCopy
  $currentLoaded = Load-Plugin $currentCopy
  $value = [Runtime.InteropServices.Marshal]::AllocHGlobal(2048)
  try {
    function Measure-Round($Delegate) {
      $watch = [Diagnostics.Stopwatch]::StartNew()
      foreach ($file in $files) {
        $name = [Runtime.InteropServices.Marshal]::StringToHGlobalUni($file)
        try {
          $result = $Delegate.Invoke($name, 0, 0, $value, 1024, 0)
          if ($result -ne 11) { throw "Unexpected line-field result $result for $file" }
        } finally {
          [Runtime.InteropServices.Marshal]::FreeHGlobal($name)
        }
      }
      $watch.Stop()
      return $watch.Elapsed.TotalMilliseconds
    }

    # Untimed JIT/delegate warm-up.
    [void](Measure-Round $baselineLoaded[1])
    [void](Measure-Round $currentLoaded[1])
    $baselineTimes = New-Object double[] $Rounds
    $currentTimes = New-Object double[] $Rounds
    for ($round = 0; $round -lt $Rounds; $round++) {
      if (($round % 2) -eq 0) {
        $baselineTimes[$round] = Measure-Round $baselineLoaded[1]
        $currentTimes[$round] = Measure-Round $currentLoaded[1]
      } else {
        $currentTimes[$round] = Measure-Round $currentLoaded[1]
        $baselineTimes[$round] = Measure-Round $baselineLoaded[1]
      }
    }
    $baselineMedian = Get-Median $baselineTimes
    $currentMedian = Get-Median $currentTimes
    $changePercent = (($currentMedian / $baselineMedian) - 1.0) * 100.0
    [pscustomobject]@{
      Files = $FileCount
      Rounds = $Rounds
      BaselineMedianMs = [Math]::Round($baselineMedian, 3)
      CurrentMedianMs = [Math]::Round($currentMedian, 3)
      ChangePercent = [Math]::Round($changePercent, 2)
    } | ConvertTo-Json -Compress
    if ($currentMedian -gt ($baselineMedian * 1.10)) {
      throw ('Relevant performance regression: {0:N2}%' -f $changePercent)
    }
  } finally {
    [Runtime.InteropServices.Marshal]::FreeHGlobal($value)
    [WdxPerfNative]::FreeLibrary($baselineLoaded[0]) | Out-Null
    [WdxPerfNative]::FreeLibrary($currentLoaded[0]) | Out-Null
  }
} finally {
  if ([IO.Directory]::Exists($tempRoot)) { [IO.Directory]::Delete($tempRoot, $true) }
}
